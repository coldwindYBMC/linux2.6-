extern void integrator_time_init(unsigned long, unsigned int);
extern unsigned long integrator_gettimeoffset(void);
